var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// packages/functions/src/admin/handler.ts
var handler_exports = {};
__export(handler_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(handler_exports);
var import_client_cognito_identity_provider = require("@aws-sdk/client-cognito-identity-provider");
var import_client_dynamodb2 = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb2 = require("@aws-sdk/lib-dynamodb");

// packages/functions/src/audit/logger.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var client = new import_client_dynamodb.DynamoDBClient({});
var docClient = import_lib_dynamodb.DynamoDBDocumentClient.from(client);
var AUDIT_TABLE = process.env.AUDIT_TABLE_NAME || "PrajnaAuditLogs";
async function logAction(userId, action, details, ip = "system") {
  try {
    await docClient.send(new import_lib_dynamodb.PutCommand({
      TableName: AUDIT_TABLE,
      Item: {
        userId,
        timestamp: Date.now(),
        action,
        details,
        ip
      }
    }));
    console.log(`[AUDIT] Action logged: ${action} by ${userId}`);
  } catch (error) {
    console.error("[AUDIT ERROR] Failed to log action:", error);
  }
}

// packages/functions/src/admin/handler.ts
var cognito = new import_client_cognito_identity_provider.CognitoIdentityProviderClient({});
var dbClient = new import_client_dynamodb2.DynamoDBClient({});
var docClient2 = import_lib_dynamodb2.DynamoDBDocumentClient.from(dbClient);
var USER_POOL_ID = process.env.USER_POOL_ID;
var TABLE_NAME = process.env.TABLE_NAME;
var handler = async (event) => {
  console.log("Admin Event:", JSON.stringify(event));
  const adminId = event.requestContext?.authorizer?.claims?.sub || "system-admin";
  const action = event.queryStringParameters?.action;
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
  };
  try {
    switch (action) {
      case "list":
        const profiles = await docClient2.send(new import_lib_dynamodb2.ScanCommand({
          TableName: TABLE_NAME,
          FilterExpression: "SK = :skValue",
          ExpressionAttributeValues: {
            ":skValue": "PROFILE"
          }
        }));
        console.log("Profiles found in DynamoDB:", profiles.Items?.length);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify(profiles.Items || [])
        };
      case "create":
        const { name, email, department, role, campus } = JSON.parse(event.body || "{}");
        await cognito.send(new import_client_cognito_identity_provider.AdminCreateUserCommand({
          UserPoolId: USER_POOL_ID,
          Username: email,
          UserAttributes: [
            { Name: "name", Value: name },
            { Name: "email", Value: email },
            { Name: "email_verified", Value: "true" },
            { Name: "custom:role", Value: role },
            { Name: "custom:department", Value: department },
            { Name: "custom:campus", Value: campus || "Bengaluru" }
          ],
          DesiredDeliveryMediums: ["EMAIL"]
        }));
        await logAction(adminId, "CREATE_USER", { name, email, role }, event.requestContext?.identity?.sourceIp || "0.0.0.0");
        return {
          statusCode: 201,
          headers,
          body: JSON.stringify({ message: "User created successfully" })
        };
      default:
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ message: "Invalid action" })
        };
    }
  } catch (error) {
    console.error("Admin error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: error.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
